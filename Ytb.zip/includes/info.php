<?php

$site = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'';

$host = $_SERVER['HTTP_HOST'];

$sitename ='MGCodes.Ga'; // Your Site Name

$logo = '/logo.png'; //Logo Picture URL

$google = 'google search consol ID'; //Google Verification Code

$alexa = 'Alexa Verification Code'; //Alexa Verification Code

$bing = 'Bing Web master Tool ID'; //Bing Verification Code

$facebook = 'https://facebook.com/mobgyan'; //Facebook Fanpage URL

$twitter = 'https://twitter.com/mobgyan'; //Twitter URL

$google = 'https://plus.google.com/MobGyan'; //Your Google+ Here

$mail = 'mail.akashmallik@gmail.com'; //Your Email Here
$info = 'Welcome To Youtube Download Zone';



$adb =''; // Do Not Try To Change YouTubepai
$adt = 'http://mgcodes.ga/youtubeapimini.php'; // Don't Change This


$keywords ='Free, downmload, video, youtube, api v3, youtube downloader to mp3, mp3, 3gp, webm, popular, news, on the spot, gaming, music, hollywood, bollywood, disney, animation, animal, funny, movies, films, konser, sinetron';
?>
