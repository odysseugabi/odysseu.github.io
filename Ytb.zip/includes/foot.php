<?php include'ucweb.php';?>
<?php
include 'includes/info.php';
?>
<div class="group" align="center">
<span class="page">External Links:</span>
<br/>
<a href="http://<?php echo ''.$host.'';?>" title="Home Page">Home Page</a> | <a href="<?php echo ''.$facebook.'';?>" target="_blank" title="Like Us On Facebook">Facebook</a> | <a href="<?php echo ''.$twitter.'';?>" target="_blank" title="Follow Us On Twitter">Twitter</a>
</div>
</div><div class="group" align="center"><div id="footer" align="center">
&copy; <?php echo date("Y") ?> <?php echo ''.$sitename.'';?>
</div>
</body>
</html>