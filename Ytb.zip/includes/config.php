<?php
include 'info.php';
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<head>
<meta http-equiv="content-type" content="application/xhtml xml; charset=utf-8"/>
<meta name="google-site-verification" content="<?php echo $google;?>"/>
<title>MGCodes.Ga YouTube Downloader</title> 
<meta name="description" content="Live Streaming  And Free Download youtube videos in hd 3gp mp4 and flv format directly on your Mobile browsers."/>
<meta name="keywords" content="<?php echo $keywords;?>"/>
<meta name="msvalidate.01" content="<?php echo ''.$bing.'';?>"/>
<meta name="alexaVerifyID" content="<?php echo ''.$alexa.'';?>" />
<meta name="robots" content="index,follow"/>
<meta property="og:title" content="Mobile Youtube Video Converter"/>
<meta name="spiders" content="all" />
<meta name="author" content="akashmallik@gmail.com"/>
<meta name="owner" content="Akash Mallik"/>
<meta name="revisit-after" content="2 Hours" />
<meta content="Aeiwi, Alexa, AllTheWeb, AltaVista, AOL Netfind, Anzwers, Canada, DirectHit, EuroSeek, Excite, Overture, Go, Google, HotBot. InfoMak, Kanoodle, Lycos, MasterSite, National Directory, Northern Light, SearchIt, SimpleSearch, WebsMostLinked, WebTop, What-U-Seek, AOL, Yahoo, Bing, WebCrawler, Infoseek, Excite, Magellan, LookSmart, CNET, googlebot-news, Googlebot" name="search engines"/>
<meta name="distribution" content="global"/>
<meta name="robots" content="All, Follow, Index" />
<meta property="og:image" content="http://i.ytimg.com/vi/'.$_GET['id'].'/default.jpg" />
<meta name="revisit-after" content="1 days">
<meta property="og:title" content="MGcodes.Ga Mobile Youtube Video Converter"/>
<meta property="og:url" content="http://<?php echo ''.$host.'';?>/"/>
<meta property="og:image" content="http://<?php echo ''.$host.'';?><?php echo ''.$logo.'';?>"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<link media="handheld,all" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<style type="text/css">
body img {max-width:98%;max-height:50%}
body {max-width:98%;max-height:50%}
width {max-width:98%;max-height:50%}
img {max-width:98%;max-height:50%}
</style>
<link rel="icon" href="/lo.png" type="image/x-icon"/>
<link rel="stylesheet" href="/style.css" type="text/css"/>
</head>
<body>
<h2 id="site-name">
<a rel="home" href="/"><center><img src="http://i.imgur.com/bFDW6O8.png" width="250" height="50" alt="MGCodes
Ga" /></center></a>
</h2>

<div id="groupp">
<div class="group" align="left">
<form action="/search.php" method="get">
<input type="text" name="q" placeholder="Search In Here"/> 
<input type="submit" value="Search" title="Search Now"/>
</form>
</div>